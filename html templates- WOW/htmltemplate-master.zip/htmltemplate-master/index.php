<?php
@include('include/header.php');
@include('include/sidebar.php');
@include('include/slider.php');
@include('include/gmlevel.php');
@include('include/body.php');
@include('include/footer.php');
?>