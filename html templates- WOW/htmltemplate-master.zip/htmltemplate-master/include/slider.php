<div class="slider">
	  <div id="slider_cont">
		  <div id="slideshow">
	       <img src="http://80.217.81.130/sliders/garroshbattle4.jpg" width="825" height="277" alt="">
        <img src="http://80.217.81.130/sliders/slide2.jpg" width="825" height="277" alt="">
        <img src="http://80.217.81.130/sliders/maxresdefault.jpg" width="825" height="277" alt="">
		  </div>
    </div>
  </div>