<div id="foot01">
</div>
<script type="text/javascript">
document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " MyServerName. All rights reserved.<br>Coded by <i style='color:#f4b62d;'>Tim Levinsson</i></p>";
</script>
</div>
</div>
</body>
</html>