<?php
@include('config/vars.php');
@include('include/header.php');
@include('include/sidebar.php');
//@include('include/body.php');
//@include('include/footer.php');
?>