<?php
$host = "localhost";
$user = "root";
$pass = "ascent";
$accdb = "auth";
$chardb = "char";
$webdb = "webros";
