<?php
session_start();
$host = $_SESSION['host'];
$dbuser = $_SESSION['user'];
$dbpass = $_SESSION['pass'];
$dbname =  $_SESSION['dbname'];
$authdb =  $_SESSION['authdb'];
$chardb =  $_SESSION['chardb'];
$worlddb =  $_SESSION['worlddb'];
?>