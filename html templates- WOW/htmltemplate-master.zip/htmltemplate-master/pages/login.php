<div class="content">
      <div class="contentbox">
	  <div class="contenttitle">Login Form</div>
        <p><center>
			<form action="models/check_login.php" method="post" autocomplete="off">
					<input type="password" style="display:none">
					<input type="text" name="uname" placeholder="USERNAME" required /><br>
					<input type="password" name="pass" placeholder="PASSWORD" required /><br>
					<input type="submit" value="Login">
				</form>
			</center>
		</p>
      </div>
</div>