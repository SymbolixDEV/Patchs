<div class="content">
      <div class="contentbox">
	  <div class="contenttitle">Registration</div>
        <p><center>
			<form action="models/regi_db.php" method="post" autocomplete="off">
				<input type="password" style="display:none;">
				<input class="textbox" type="text" name="uname"  placeholder="Username" required /><br>
				<input class="textbox" type="password" name="pass" placeholder="Password" required /><br>
				<input class="textbox" type="password" name="pass2" placeholder="Password" required /><br>
				<input class="textbox" type="email" name="email" placeholder="Email" required /><br>
				<input class="loginbutton" type="submit" value="register">
			</form>
			</center>
		</p>
      </div>
</div>