<script>setTimeout('top.location = \'?p=index\'', 3000);</script>
<div class="content">
      <div class="contentbox">
        <p><center>
				<h1>Registration Successful !</h1>
			</center>
		</p>
      </div>
</div>