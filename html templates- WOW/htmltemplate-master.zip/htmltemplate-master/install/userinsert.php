<?php
@include('config/vars.php');
@include('include/header.php');
@include('include/sidebar.php');
@include('include/body2.php');
@include('include/footer.php');
?>