<aside>
      <div id="sidenav">
      <ul>
        <li><a href="#">Database Configuration</a></li>
        <li><a href="#">Database Installation</a></li>
        <li><a href="#">Database Settings</a></li>
        <li><a href="#">Finished !</a></li>
      </ul>
      </div>
    </aside>