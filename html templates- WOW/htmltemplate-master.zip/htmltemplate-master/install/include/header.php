<?php 
  @include('../config/vars.php');
  @include('../config/db_connect.php');
?>
  <!DOCTYPE html>
  <html>
  <head>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<meta charset="UTF-8">
	<meta name="description" content="Web Design">
	<meta name="author" content="Nirelz">
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <header>
      <div id="head">
        <did class="logo"><a href="#">My Website</a></div>
      </div>
    </header>