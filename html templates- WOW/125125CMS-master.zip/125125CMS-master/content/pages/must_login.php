	<div class="title">
		<center>Permission denied</center>
	</div>
	<div class="message">
		<center>
			<p>Must login first to view this page</p>
		</center>
        <br />
	</div>