<div id="news">
	<div class="title">
		<center>Welcome to HellguardWoW</center>
	</div>
	<div class="indexmessage">
		<div class="postformside">
			<div class="username">
	        	Tok124
	      	</div>
	      	<div class="avatar">
	    	</div>
	    </div>
		<div class="usermessage">
			<center>Hello!</center><br /><br />
			Hello and Welcome to HellguardWoW. This server is still in development. We are just as excited as you are to see the finished result. We are waiting for or Developer to make items and stuff.
			We are trying to make everything as unique as possible ! And about the website. The website is in Developement too... That means that we don't have a Donate/Vote/Store yet.
			If you want to make a donation you have to create an ingame ticket.<br />
			<br />
			<b>More info about donations:</b><br />
			If you donate before we have finished the items for players then you will reciece a special donation gift. You will get a donor+ item... Donor+ is ONLY avalible at this point.
			You cannot get it when the server is finished. Donor+ means that we make a item for you and you can choose your own name and your own namecolor and you own displayID aswell.
			Stats will ALWAYS be higher than normal donor gear.<br />
			<br />
			<b>More Info about Prices:</b><br />
			5$ = Off-Set Piece<br />
			7$ = One-Hand Weapon<br />
			10$ = Set Piece<br />
			12$ = Two-Hand Weapon<br />
			15$ = VIP Rank<br />
			25$ = Full VIP Set (5 Pieces)<font color="red">HOT!</font>
	  	</div>
	</div>
    <div class="title">
		<center>Announcement</center>
	</div>
	<div class="indexmessage">
		<div class="postformside">
			<div class="username">
	      		Tok124
	     	</div>
	      	<div class="avatar">
	      	</div>
	    </div>
		<div class="usermessage">
			We are NOT recruiting GM's atm. However, We are in big need of help with creating items. If you are lazy and unexperiences then please don't even bother to make an application...
			However, If you really enjoy to create items and have experience with the SQL Language then you are welcome to join us ! If you only know how to make items on WoW-V then you don't know the SQL Language.
			I don't accept anyone who only knows how to make items on wow-v !
		</div>
	</div>
</div>   
</div>