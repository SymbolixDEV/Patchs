<script>setTimeout('top.location = \'../hellguard/?p=index\'', 3000);</script>
<div id="news">
	<div class="title">
		<center>Register</center>
	</div>
	<div class="message">
		<center>
			<p style="color:white; font-size:20px;">Registration complete!</p>
		</center>
	</div>
</div>  
</div>
