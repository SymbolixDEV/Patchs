<div id="news">
	<div class="title">
		<center>Not Found</center>
	</div>
	<div class="message">
		<h1><b><center>The requested site was not found !</center></b></h1>
		<br />
	</div>
</div>
</div>