<div id="news">
	<div class="title">
		<center>Downloads</center>
	</div>
	<div class="message">
		<center>
			<table border="1" style="border: 1px solid #0d0f0d;">
				<tr>
					<th colspan="2" style="text-align:center;">Custom Patch</th>
				</tr>
				<tr>
					<th><img src="content/images/download.png"</th>
					<td><a href="downloads/patch-A.mpq">Patch-A.MPQ</a></td>
				</tr>
			</table>
		</center>
        <br />
	</div>
</div>	  
</div>
