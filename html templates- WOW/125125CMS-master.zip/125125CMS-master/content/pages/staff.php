<div id="news">
	<div class="title">
		<center>Staff Team of Hellguard-WoW</center>
	</div>
	<div class="message">
		<center>
			<table border="1" style="border-collapse:collapse; border:1px solid #0d0f0d;">
			  <tr>
			    <th class="userinfo-th" style='padding:10px;'>Name</th>
			    <th class="userinfo-th" style='padding:10px;'>Rank</th>
			    <th class="userinfo-th" style='padding:10px;'>Contact Email</th>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Tok124</td>
			    <td class="userinfo-td" style='padding:10px;'>Owner</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: Tim-Levinsson@hotmail.com">Tim-Levinsson@hotmail.com</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Dev4Life</td>
			    <td class="userinfo-td" style='padding:10px;'>Dev</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: shehabdiaa12345@gmail.com">shehabdiaa12345@gmail.com</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Sefax</td>
			    <td class="userinfo-td" style='padding:10px;'>Dev</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: ekortbawi19@gmail.com">ekortbawi19@gmail.com</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Braingames</td>
			    <td class="userinfo-td" style='padding:10px;'>Head-GM</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: mar4oni22@abv.bg">mar4oni22@abv.bg</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Namira</td>
			    <td class="userinfo-td" style='padding:10px;'>Head-GM</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: dimitris-g4@hotmail.com">dimitris-g4@hotmail.com</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Loff</td>
			    <td class="userinfo-td" style='padding:10px;'>GM</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: sweethanyou@gmail.com">sweethanyou@gmail.com</a></td>
			  </tr>
			  <tr>
			    <td class="userinfo-td" style='padding:10px;'>Freeway</td>
			    <td class="userinfo-td" style='padding:10px;'>GM</td>
			    <td class="userinfo-td" style='padding:10px;'><a href="mailto: freewaysohawt@hotmail.com">freewaysohawt@hotmail.com</a></td>
			  </tr>
			</table>
		</center>
	</div>
</div>    
</div>