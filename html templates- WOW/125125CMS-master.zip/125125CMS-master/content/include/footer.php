		</div>
		<center><footer id="foot01"></footer></center>
		<script src="content/js/script.js"></script>
	</div>
</body>
</html>