<div id="nav">
	<ul>
		<?php
		if(!isset($_SESSION['username'])){
			echo '<li class="class1"><a href="?p=index"><span>Home</span></a></li>
	  		<li class="class2"><a href="../forum"><span>Forum</span></a></li>
	  		<li class="class3"><a href="?p=register"><span>Register</span></a></li>
	  		<li class="class4"><a href="?p=connect"><span>Connect</span></a></li>
	  		<li class="class5"><a href="?p=download"><span>Downloads</span></a></li>
	  		<li class="class6"><a href="?p=staff"><span>Staff Team</span></a></li>';
		}
		else{
			echo '<li class="class1"><a href="?p=index"><span>Home</span></a></li>
	  		<li class="class2"><a href="../forum"><span>Forum</span></a></li>
	  		<li class="class3"><a href="?p=vote"><span>Vote</span></a></li>
	  		<li class="class4"><a href="?p=donate"><span>Donate</span></a></li>
	  		<li class="class5"><a href="?p=ucp"><span>User Panel</span></a></li>
	  		<li class="class6"><a href="?p=connect"><span>Connect</span></a></li>
	  		<li class="class7"><a href="?p=download"><span>Downloads</span></a></li>
	  		<li class="class8"><a href="?p=staff"><span>Staff Team</span></a></li>';
		}
		?>
	</ul>
</div>
<center><img style="margin-top:170px;" src="content/images/hellguardwowlogotest2.png"></center>
<div id="wrapper">
  <div id="container">
	<?php include ('content/include/sidebar.php') ?>
	<div id="contentbox">