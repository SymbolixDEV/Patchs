<div id="slider">
	<div id="slider_cont">
		<div id="slideshow">
	        <img src="content/images/Slider1.jpg" alt="" />
	        <img src="content/images/Slider2.jpg" alt="" />
			<img src="content/images/Slider3.jpg" alt="" />
			<img src="content/images/Slider4.jpg" alt="" />
			<img src="content/images/Slider5.jpg" alt="" />
			<img src="content/images/Slider6.jpg" alt="" />
		</div>
    </div>
</div>